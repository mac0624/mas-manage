#!/bin/sh

# 共通変数の設定
. ./SetCommonEnv.sh

# セットの作成（部品セット、企業セット）
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.CreateMboFromCsv SETS ./inputdata/sets.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

# 通貨コードの作成
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.CreateMboFromCsv CURRENCY ./inputdata/currency.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

# 組織の作成
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.CreateMboFromCsv ORGANIZATION ./inputdata/organization.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

# 作業タイプの作成
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.CreateMboFromCsv WORKTYPE ./inputdata/worktype.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

# 会計期間の作成
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.CreateMboFromCsv FINANCIALPERIODS ./inputdata/financialperiods.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

# GL 勘定科目の構成の作成
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.CreateMboFromCsv GLCONFIGURE ./inputdata/glconfigure.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

# GL 勘定科目コンポーネント設定の作成
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.CreateMboFromCsv GLCOMPONENTS ./inputdata/glcomponents.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

# GL 勘定科目の作成
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.CreateMboFromCsv CHARTOFACCOUNTS ./inputdata/chartofaccounts.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

# 組織のアクティブ化
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.ActivateOrg ./inputdata/activateorg.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

# サイトの作成
$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.CreateMboFromCsv SITE ./inputdata/site.csv
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

echo 初期データの投入が完了しました。
exit 0
