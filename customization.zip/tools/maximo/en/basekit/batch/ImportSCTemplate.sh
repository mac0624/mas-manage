#!/bin/sh

# 共通変数の設定
. ./SetCommonEnv.sh

$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.ImportSCTemplate ./sctemplate/sc_for_admin.xml 管理者用テンプレート
if [ $? -gt 0 ]; then
  echo $ERRMSG
  exit 1
fi

echo スタートセンターテンプレートのインポートが完了しました。
exit 0

