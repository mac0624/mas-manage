#!/bin/sh

. ./SetCommonEnv.sh

$JAVAPATH/java -classpath $CLASSPATH jp.co.exa_corp.basekit.MaxRmiClient
